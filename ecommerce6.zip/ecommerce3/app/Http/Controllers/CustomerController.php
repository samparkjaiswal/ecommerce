<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Customer;
use App\Models\Product;

class CustomerController extends Controller
{
    public function cureg()
    {
        return view('/customer/customerreg');
    }

    public function culogin()
    {
        return view('/customer/customerlogin');
    }

    public function cuhome()
    {
         return view('/customer/home');
     
    }

    public function dash()
    {
        return view('/admin/dash');
    }

    public function addproduct()
    {
       return view('/admin/addproduct');
    }


    public function cuinsert(Request $request)
    {
        // $request->validate([

        //     'name' => 'required',
        //     'email' => 'required|email|unique:customers',
        //     'password' => 'required|min:5|max:12',
        //     'mobile' => 'required|min:10|max:12',
        //     'address' => 'required'
    
        //    ]);

           $customer = new Customer;

           $customer->name = $request->name;
           $customer->email = $request->email;
           $customer->password = $request->password;
           $customer->mobile = $request->mobile;
           $customer->address = $request->address;
            $customer->save();

    }

    public function login(Request $request)
    {
       

        $customer = Customer::where('email', '=' ,$request->email)->first();
        
       
       
        if($customer)
        {
          
          if($request->password == $customer->password)
          {
     
            $request->session()->put('Loginid',$customer->id);
            $request->session()->put('Name',$customer->name);
            $request->session()->put('role',$customer->role);
            //return redirect(route('admin.dash'));
            return response()->json([ [1] ]);
          }
        }
        else
        {
            return response()->json([ [3] ]);
        }
      
     }


     public function logout()
     {
        if(session()->has('Loginid'))
        {
            session()->pull('Loginid');
            return redirect(route('customer.home'));
        }
     }

     public function insertproduct(Request $request)
     {
        $product = new Product;

       

        //The function GetClientOriginalName() is used to retrieve the file's original name at the time of upload in laravel and that'll only be possible if the data is sent as array and not as a string.
        if($request->hasFile('file'))
        {
        
        $file =$request->file('file');
        // $orgfilename = $file->getClientOriginalName();
        $orgextension =$file->getClientOriginalExtension();

         // $files=  $request->file('file')->storeAs('upload',$filename);

        $filename = time() . '.' .$orgextension;
       
        $file->move(public_path('/images/upload'),$filename);

       
        $product->productname = $request->pname;
        $product->file= $filename;
        
        }
      
        $product->save();


     }

    //  public function displayproduct()
    //  {
        
       

    //       //The compact() function is used to convert given variable to to array in which the key of the array will be the name of the variable and the value of the array will be the value of the variable.
        
    //     $products = Product::all();

    //  
    // //    return response()->json([
    // //         'products'=>$products,
    // //    ]);
    //   
     
    //  }

     public function displayproduct()
     {
        
       

          //The compact() function is used to convert given variable to to array in which the key of the array will be the name of the variable and the value of the array will be the value of the variable.
        
        $products = Product::all();

       $data=compact('products');
   
       return view('/admin/addproduct')->with($data);
     
     }


  
    public function carddisp()
    {
        $records = Product::all();

        return response()->json([
                    'records'=>$records,
               ]);

        //$data=compact('records');
        //return view('/customer/home')->with($data);

    //     if(session()->has('Loginid'))
    //     {
    //         return view('/customer/home')->with($data);
    //     }
    //     else
    //     {
           
    //         return view('/customer/home',)->with($data);
    //     }
     }

    
}
