<!doctype html>
<html lang="en">
  <head>
    <title>Login</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>


    <div class="container">

        <div class="row">
            
            <div class="col-md-4 offset-md-4">

            <form id="loginfrm" autocomplete="off">
                @csrf
                <h2 class="text-center danger">Login</h2>


            <div class="form-group">
                <label for="email">Email</label>
                <input type="text" class="form-control" name="email" value="" required id="email" aria-describedby="helpId" placeholder="Enter email id">
                <span></span>
              </div>

              <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" name="password" required value="" id="password" aria-describedby="helpId" placeholder="Create password">
                <span></span>
              </div>

              

              <button type="submit" class="btn btn-success">Sign In</button><br>
              <div id="err" style="color:red"></div>
              {{-- <a href="{{ route('customer.reg') }}">I don't have an account, create new</a> --}}
              {{-- <a href="{{ route('customer.home') }}">Go to page</a>  --}}
            </form>

        </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.1.min.js" integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>


    <script>

      $(document).ready(function(){

        $('#loginfrm').submit(function(e){

          e.preventDefault();
          //console.log('hello');

          $.ajax({
            url:'/customer/login',
            type: 'post',
            data: $('#loginfrm').serialize(),
            success:function(response){
                    console.log(response);

                    if(response == 1)
                    {
                      window.location.replace('/admin/dash');
                      // window.location.replace('/customer/home');
                    }
                    else if(response == 3)
                    {
                     // $(#err).hide().html("Username password incorrect");
                     alert('Wrong email or password');
                    }
                 
                    // alert('Login success');window.location.href='{{ route('admin.dash') }}';
                     },
                  // error:function(error){
                  //  console.log(error);
                  //   alert('Wrong email id/password');
                  // }

          });

        });

      });

      </script>
 <script src="https://code.jquery.com/jquery-3.6.1.min.js" integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>

 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
   
  </body>
</html>