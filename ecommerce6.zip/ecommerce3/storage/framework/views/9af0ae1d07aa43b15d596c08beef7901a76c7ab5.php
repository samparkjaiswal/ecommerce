<?php $__env->startSection('content'); ?>




<div class="container">

    <div class="row" style="margin-top:50px">

        <div class="col-md-6">

            

            <button type="submit" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#ProductModal">Add Product</button>

            <div class="modal" id="ProductModal">

            <div class="modal-dialog">
                <div class="modal-content">
      
                     <div class="modal-header">
                        <h5 class="modal-title">Login</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>


                    <div class="modal-body">


                        <form id="addproduct" autocomplete="off" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                              <label for="">Product Name</label>
                              <input type="text" name="pname" id="pname" class="form-control" placeholder="Enter product name" aria-describedby="helpId">  
                            </div>
                    
                            <div class="form-group">
                                <label for="">Upload File</label>
                                <input type="file" name="file" id="" class="form-control" placeholder="Enter name" aria-describedby="helpId">
                            </div>

                                
                                <div class="modal-footer">

                                    <button type="button" class="btn-close btn btn-secondary" data-bs-dismiss="modal">Close</button>
              
                                    <button type="submit" class="btn btn-success" name="submit" id="add">Save Product</button>
                                    
              
                                  </div>
                    
                        </form>


                    </div>
                </div>
            </div>
        </div>

       
        </div>

         <div class="col-md-6">

            <div class="card">
                <div class="card-header bg-warning text-white">All Products</div>
                <div class="card-body">

                    

                    
                        <table>
                            <thead>
                                <tr>
                                    <th>Product_Id</th>
                                    <th>Name</th>
                                    <th>File</th>
                                </tr>
                            </thead>

                            <tbody>
                               <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   
                               
                                 
                                <tr>
                                    <td><?php echo e($pro->product_id); ?></td>
                                    <td><?php echo e($pro->productname); ?></td>

                                    <td>
                                    
                                        <img src="<?php echo e('/images/upload/'.$pro->file); ?>" width="50" height="50" alt="Image">
                                        
                                    </td>
                                </tr> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </tbody>
                        </table>


                    

                </div>
            </div>

        </div>
    </div>
</div>












<?php $__env->stopSection(); ?>



<script src="https://code.jquery.com/jquery-3.6.1.min.js" integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>







<script>




    $(document).ready(function(){

       

        // fetchproduct();
        
        // function fetchproduct()
        // {
        // $.ajax({
        //         type: "GET",
        //         url:"/disproduct",
        //         dataType: "json",
        //         success:function(response){
        //             console.log(response.products);
                  
        //         }

        //         });
        // }

        // $('#addproduct').submit(function(){
        //   //  e.preventDefault();
        //     $('#addproduct').load('#addprduct');

            
        // });



        // fetchProduct();
        // function fetchProduct()
        // {
        //     $.ajax({
        //         type: "GET",
        //         url: "/disproduct",
        //         dataType: "json",
        //         success: function(response){ 
        //             //console.log(response.product);
        //             $('tbody').html("");
        //             $.each(response.product, function (key, item) { 

        //                 $('tbody').append('<tr>\
        //                             <td>'+item.product_id+'</td>\
        //                             <td>'+item.productname+'</td>\
        //                             <td> <img src="/images/upload/'.+item.file+'" width="50" height="50" alt="Image"></td>\
        //                         </tr>');
                         
        //             });

        //         }

        //     });
        // }





        $('#addproduct').submit(function(e){

            e.preventDefault();
            
            let formdata = new FormData($('#addproduct')[0]);

            $.ajax({
                type: "POST",
                url: "/admin/addproduct",
                data: formdata,
                contentType:false,
                processData:false,
                success: function (response) {
                //console.log(response);
                $('#ProductModal').modal('hide');
                alert('Product Add');
                
                },
                error:function(error){
                //console.log(error);
                $('#ProductModal').modal('hide');
                alert('Product Not Add');
          }
            });

        });
    });
</script>



















   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>


<?php echo $__env->make('admin.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/ecommerce3/resources/views//admin/addproduct.blade.php ENDPATH**/ ?>