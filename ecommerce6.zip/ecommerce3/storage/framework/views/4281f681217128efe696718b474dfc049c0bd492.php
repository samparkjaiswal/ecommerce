<?php $__env->startSection('content'); ?>




<div class="container">

    <div class="row" style="margin-top:50px">

        <div class="col-md-6">

            <div class="card">
                <div class="card-header bg-primary text-white">Add New Product</div>
                    <div class="card-body">

                        <form id="addproduct" autocomplete="off" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                              <label for="">Product Name</label>
                              <input type="text" name="pname" id="pname" class="form-control" placeholder="Enter product name" aria-describedby="helpId">  
                            </div>
                    
                            <div class="form-group">
                                <label for="">Upload File</label>
                                <input type="file" name="file" id="" class="form-control" placeholder="Enter name" aria-describedby="helpId">
                            </div>

                                <button type="submit" class="btn btn-success">Save Product</button>
                    
                        </form>

                    </div>
                
            </div>

       
        </div>

         <div class="col-md-6">

            <div class="card">
                <div class="card-header bg-warning text-white">All Products</div>
                <div class="card-body">

                    

                    
                        <table>
                            <thead>
                                <tr>
                                    <th>Product_Id</th>
                                    <th>Name</th>
                                    <th>File</th>
                                </tr>
                            </thead>

                            <tbody>
                               
                                    
                                
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td>
                                        
                                    </td>
                                </tr>
                                
                            </tbody>
                        </table>


                    

                </div>
            </div>

        </div>
    </div>
</div>












<?php $__env->stopSection(); ?>



<script src="https://code.jquery.com/jquery-3.6.1.min.js" integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>







<script>
    $(document).ready(function(){

        fetchproduct();

        function fetchproduct()
        {
            $.ajax({
                type: "GET",
                url:"/admin/disproduct",
                dataType: "json",
                success:function(response){
                    console.log(response.product);

                }
            })
        }



        $('#addproduct').submit(function(e){

            e.preventDefault();
            
            let formdata = new FormData($('#addproduct')[0]);

            $.ajax({
                type: "POST",
                url: "/admin/addproduct",
                data: formdata,
                contentType:false,
                processData:false,
                success: function (response) {
                console.log(response);
                alert('Product Add');
                },
                error:function(error){
                console.log(error);
                alert('Product Not Add');
          }
            });

        });
    });
</script>



















   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>


<?php echo $__env->make('admin.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/ecommerce (2)/resources/views//admin/addproduct.blade.php ENDPATH**/ ?>