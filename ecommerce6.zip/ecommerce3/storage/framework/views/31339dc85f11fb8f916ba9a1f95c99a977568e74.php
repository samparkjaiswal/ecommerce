<!doctype html>
<html lang="en">
  <head>
    <title>Registration</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>


    <div class="container">

        <div class="row">
            
            <div class="col-md-4 offset-md-4">
            <form  id="addform" autocomplete="off">

              

                <?php echo csrf_field(); ?>
                <h2 class="text-center danger">Registration</h2>
            <div class="form-group">
              <label for="name">Name</label>
              <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" id="" aria-describedby="helpId" placeholder="Enter name">
              <span class="text-danger"><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
            </div>


            <div class="form-group">
                <label for="email">Email</label>
                <input type="text" class="form-control" name="email" value="<?php echo e(old('email')); ?>" id="" aria-describedby="helpId" placeholder="Enter email id">
                <span class="text-danger"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
              </div>

              <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" name="password" value="" id="" aria-describedby="helpId" placeholder="Create password">
                <span class="text-danger"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
              </div>

              <div class="form-group">
                <label for="mobile">Mobile</label>
                <input type="tel" class="form-control" name="mobile" value="<?php echo e(old('mobile')); ?>" id="" aria-describedby="helpId" placeholder="Enter mobile">
                <span class="text-danger"><?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
              </div>

              <div class="form-group">
                <label for="address">Address</label>
                <textarea name="address" id="" class="form-control" value="<?php echo e(old('address')); ?>" placeholder="Enter full address"></textarea>
                <span class="text-danger"><?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
              </div>

              <button type="submit" class="btn btn-success">Sign Up</button><br>
              
            </form>

        </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.1.min.js" integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>
      
    <script type="text/javascript">
      $(document).ready(function(){
        $('#addform').submit(function(e){
          e.preventDefault();//e means event prevenDefault function it's use for don't do any action on click any button or url
          //console.log("hello");
          // var data = {                  //make a object of all form data
          //   'name': $('#name').val(),
          //   'email': $('#email').val(),
          //   'password': $('#password').val(),
          //   'moblile': $('#mobile').val(),
          //   'address': $('#address').val(),
          
         // console.log(data);

        
        $.ajax({
          url:"/customer/reg",
          data:$('#addform').serialize(),
          type:'post',
          success:function(result){
            console.log(result);
            $('#RegisterModal').modal('hide');
            alert('Data Saved');window.location.href='<?php echo e(route('customer.login')); ?>';
          },
          error:function(error){
            console.log(error);
            alert('Data Not Saved');
          }
        });

         });

        });
      
            // The serialize() method creates a URL encoded text string by serializing form values.

            // You can select one or more form elements (like input and/or text area), or the form element itself.

            // The serialized values can be used in the URL query string when making an AJAX request.



      </script>
    
    <script src="https://code.jquery.com/jquery-3.6.1.min.js" integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>

   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
   
  </body>
</html><?php /**PATH /opt/lampp/htdocs/ecommerce3/resources/views//customer/customerreg.blade.php ENDPATH**/ ?>