<!doctype html>
<html lang="en">
  <head>
    <title>Ecommerce Website</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <style>

      .card-img-top{
        width:100%;
        height:200px;
        object-fit: contain;
      }

    </style>

  </head>
  <body>
      
   <div class="container-fluid p-0">
     
    <nav class="navbar navbar-expand-lg  bg-info">
      <div class="container-fluid">
        <a class="navbar-brand" style="color:white;font-weight:bold" href="#">Logo</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">

          <ul class="navbar-nav me-auto mb-2 mb-lg-0">

            <li class="nav-item">
              <a class="nav-link active" aria-current="page"  href="#"><span class="fa fa-home" style="color:white;font-weight:bold"> Home</span></a>
            </li>

            
            <!-- Modal -->

            


            <div class="modal" id="RegisterModal">
              <div class="modal-dialog">
                  <div class="modal-content">
          
                      <div class="modal-header">
                          <h5 class="modal-title">Customer Registration</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                      </div>

                      <div class="modal-body">

                        <form id="addform">

                       
                          
            
                            <?php echo csrf_field(); ?>
                         
                        <div class="form-group">
                          <label for="name">Name</label>
                          <input type="text" class="form-control" name="name"  value="<?php echo e(old('name')); ?>" id="name" aria-describedby="helpId" placeholder="Enter name">
                          <span class="text-danger"><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
            
            
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="text" class="form-control" name="email" value="<?php echo e(old('email')); ?>" id="email" aria-describedby="helpId" placeholder="Enter email id">
                            <span class="text-danger"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                          </div>
            
                          <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" class="form-control" name="password" value="" id="password" aria-describedby="helpId" placeholder="Create password">
                            <span class="text-danger"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                          </div>
            
                          <div class="form-group">
                            <label for="mobile">Mobile</label>
                            <input type="tel" class="form-control" name="mobile" value="<?php echo e(old('mobile')); ?>" id="mobile" aria-describedby="helpId" placeholder="Enter mobile">
                            <span class="text-danger"><?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                          </div>
            
                          <div class="form-group">
                            <label for="address">Address</label>
                            <textarea name="address" id="address" class="form-control" value="<?php echo e(old('address')); ?>" placeholder="Enter full address"></textarea>
                            <span class="text-danger"><?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                          </div>
 
                          <div class="modal-footer">

                            <button type="button" class="btn-close btn btn-secondary" data-bs-dismiss="modal">Close</button>

                            <button type="submit" class="btn btn-success" name="submit" id="frmSubmit">Sign Up</button>
                            

                          </div>
            
                         
                          

                        </form>
                       
                      </div>

                    
          

                  </div>

              </div>
            </div>
            <script src="https://code.jquery.com/jquery-3.6.1.min.js" integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>
           
           

<script type="text/javascript">
              $(document).ready(function(){
                $('#addform').submit(function(e){
                  e.preventDefault();//e means event prevenDefault function it's use for don't do any action on click any button or url
                  //console.log("hello");
                  // var data = {                  //make a object of all form data
                  //   'name': $('#name').val(),
                  //   'email': $('#email').val(),
                  //   'password': $('#password').val(),
                  //   'moblile': $('#mobile').val(),
                  //   'address': $('#address').val(),
                  
                 // console.log(data);

                //  $.ajax({
                //   type: "POST",
                //   url: "/customer/reg",
                //   data: $('#addform').serialize(),  
                //   success: function (response) {
                //     console.log(response);
                //    // $('#RegisterModal').modal('hide')
                //     alert('Data Saved');
                //   },
                //   error: function(error){
                //     console.log(error)
                //     alert('Data Not Saved');
                //   }
                //  });
                $.ajax({
                  url:"/customer/reg",
                  data:$('#addform').serialize(),
                  type:'post',
                  success:function(result){
                    console.log(result);
                    $('#RegisterModal').modal('hide');
                    alert('Data Saved');
                  },
                  error:function(error){
                    console.log(error);
                    alert('Data Not Saved');
                  }
                });

                 });

                });
              
                    // The serialize() method creates a URL encoded text string by serializing form values.

                    // You can select one or more form elements (like input and/or text area), or the form element itself.

                    // The serialized values can be used in the URL query string when making an AJAX request.



              </script>



              
            
                <li class="nav-item">
                  <a class="nav-link"   data-bs-toggle="modal" data-bs-target="#RegisterModal"><span class="fa fa-user-plus" style="color:white;font-weight:bold"> Register</span></a>
                </li>
    
             


            

            <li class="nav-item">
              <a class="nav-link"  href="#"><span class="fa fa-shopping-cart" style="color:white;font-weight:bold"> Cart</span></a>
            </li>

            
            
            
          </ul>
          <form class="d-flex" role="search" style="margin-left:600px;">
            <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-success" type="submit">Search</button>
          </form>
        </div>
      </div>
    </nav>

    <!--Second Chiled--->

    <nav class="navbar navbar-expand-lg navbar-dark bg-secondary">
     <ul class="navbar-nav me-auto">

      <li class="nav-item">
        <a class="nav-link" href="#"><span class="fa fa-user" style="color:white;font-weight:bold"> Welcome Guest</span></a>

        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('customer.login')); ?>"><span class="fa fa-sign-in" style="color:white;font-weight:bold"> Login</span></a>
      </li>
     </ul>
    </nav>

    <!--third child-->

    <div class="" style="background:#dae452">
      <h3 class="text-center" style="font-weight:bold">Our Store</h3>
      <p class="text-center">Do Something New For You</p>
  
    </div>

    <!--Fourht child-->

    <div class="row">
      <div class="col-md-12">
        <!--product-->
        <div class="row">
          <div class="col-md-4 mb-4">
            <div class="card">
              <img src="<?php echo e(asset('img/jam.jpg')); ?>" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-info">Add to cart</a>
                <a href="#" class="btn btn-secondary">View more</a>
              </div>
            </div>
          </div>
          <div class="col-md-4 mb-4">
            <div class="card">
              <img src="<?php echo e(asset('img/camera.jpg')); ?>" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-info">Add to cart</a>
                <a href="#" class="btn btn-secondary">View more</a>
              </div>
            </div>
          </div>
          <div class="col-md-4 mb-4">
            <div class="card">
              <img src="<?php echo e(asset('img/tata.jpeg')); ?>" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-info">Add to cart</a>
                <a href="#" class="btn btn-secondary">View more</a>
              </div>
            </div>
          </div>

          <div class="col-md-4 mb-4">
            <div class="card">
              <img src="<?php echo e(asset('img/tata.jpeg')); ?>" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-info">Add to cart</a>
                <a href="#" class="btn btn-secondary">View more</a>
              </div>
            </div>
          </div>

          <div class="col-md-4 mb-4">
            <div class="card">
              <img src="<?php echo e(asset('img/tata.jpeg')); ?>" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-info">Add to cart</a>
                <a href="#" class="btn btn-secondary">View more</a>
              </div>
            </div>
          </div>

          <div class="col-md-4 mb-4">
            <div class="card">
              <img src="<?php echo e(asset('img/tata.jpeg')); ?>" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-info">Add to cart</a>
                <a href="#" class="btn btn-secondary">View more</a>
              </div>
            </div>
          </div>
        </div>
      </div>


       <!--sidenav-->

      

    </div>


    <!--Footer-->

    <div class="bg-info p-3 text-center">
      <p>@Copyright Designed By Ashriya Infotech</p>
    </div>


   </div>
   <script src="https://code.jquery.com/jquery-3.6.1.min.js" integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>

   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
   
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    
  </body>
</html><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views//customer/home.blade.php ENDPATH**/ ?>