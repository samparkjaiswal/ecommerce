<!doctype html>
<html lang="en">
  <head>
    <title>Ecommerce Website</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <style>

      .card-img-top{
        width:100%;
        height:200px;
        object-fit: contain;
      }

    </style>

  </head>
  <body>
      
   <div class="container-fluid p-0">
     
    <nav class="navbar navbar-expand-lg  bg-info">
      <div class="container-fluid">
        <a class="navbar-brand" style="color:white;font-weight:bold" href="#">Logo</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">

          <ul class="navbar-nav me-auto mb-2 mb-lg-0">

            <li class="nav-item">
              <a class="nav-link active" aria-current="page"  href="#"><span class="fa fa-home" style="color:white;font-weight:bold"> Home</span></a>
            </li>

            
            <!-- Modal -->

            


            
            
           
           




              
            
                 <!-- For Registration Link -->

                <li class="nav-item">
                  <a class="nav-link" href="<?php echo e(route('customer.reg')); ?>"><span class="fa fa-user-plus" style="color:white;font-weight:bold"> Register</span></a>
                </li>
    
    
             


            <?php if(session()->has('Loginid')): ?>
              
          

            <li class="nav-item">
              <a class="nav-link"  href="#"><span class="fa fa-shopping-cart" style="color:white;font-weight:bold"> Cart</span></a>
            </li>
            <?php endif; ?>
            
            
            
          </ul>
          <form class="d-flex" role="search" style="margin-left:600px;">
            <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-success" type="submit">Search</button>
          </form>
        </div>
      </div>
    </nav>

    <!--Second Chiled--->

    <nav class="navbar navbar-expand-lg navbar-dark bg-secondary">
     <ul class="navbar-nav me-auto">
      
      
  
      <li class="nav-item">
        <a class="nav-link" href="#"><span class="fa fa-user" style="color:white;font-weight:bold"> Welcome 

          <?php if(session()->has('Loginid')): ?>
          <?php echo e(session('Name')); ?> <?php endif; ?>

        </span></a>
         
      </li>
       

         


             <!-- For Modal Login link -->

      <?php if(!session()->has('Loginid')): ?>
        
      
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('customer.login')); ?>"  ><span class="fa fa-sign-in" style="color:white;font-weight:bold"> Login</span></a>
    </li>
    <?php else: ?>
      <li class="nav-item">
        <a class="nav-link active" aria-current="page"  href="<?php echo e(route('logout')); ?>" style="margin-left:1200px"><span class="fa fa-sign-out" style="color:white;font-weight:bold"> Logout</span></a>
      </li>
    <?php endif; ?>
     </ul>
    </nav> 

    






    <!--third child-->

    <div class="" style="background:#dae452">
      <h3 class="text-center" style="font-weight:bold">Our Store</h3>
      <p class="text-center">Do Something New For You</p>
  
    </div>

    <!--Fourht child-->

    <div class="row">
      <div class="col-md-12">
        <!--product-->
        <div class="row">
          <div class="col-md-4 mb-4">
            <div class="card">
              <img src="<?php echo e(asset('img/jam.jpg')); ?>" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-info">Add to cart</a>
                <a href="#" class="btn btn-secondary">View more</a>
              </div>
            </div>
          </div>
          <div class="col-md-4 mb-4">
            <div class="card">
              <img src="<?php echo e(asset('img/camera.jpg')); ?>" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-info">Add to cart</a>
                <a href="#" class="btn btn-secondary">View more</a>
              </div>
            </div>
          </div>
          <div class="col-md-4 mb-4">
            <div class="card">
              <img src="<?php echo e(asset('img/tata.jpeg')); ?>" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-info">Add to cart</a>
                <a href="#" class="btn btn-secondary">View more</a>
              </div>
            </div>
          </div>

          <div class="col-md-4 mb-4">
            <div class="card">
              <img src="<?php echo e(asset('img/tata.jpeg')); ?>" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-info">Add to cart</a>
                <a href="#" class="btn btn-secondary">View more</a>
              </div>
            </div>
          </div>

          <div class="col-md-4 mb-4">
            <div class="card">
              <img src="<?php echo e(asset('img/tata.jpeg')); ?>" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-info">Add to cart</a>
                <a href="#" class="btn btn-secondary">View more</a>
              </div>
            </div>
          </div>

          <div class="col-md-4 mb-4">
            <div class="card">
              <img src="<?php echo e(asset('img/tata.jpeg')); ?>" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-info">Add to cart</a>
                <a href="#" class="btn btn-secondary">View more</a>
              </div>
            </div>
          </div>
        </div>
      </div>


       <!--sidenav-->

      

    </div>


    <!--Footer-->

    <div class="bg-info p-3 text-center">
      <p>@Copyright Designed By Ashriya Infotech</p>
    </div>


   </div>
   <script src="https://code.jquery.com/jquery-3.6.1.min.js" integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>

   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
   
  
  </body>
</html><?php /**PATH /opt/lampp/htdocs/ecommerce (2)/resources/views/customer/home.blade.php ENDPATH**/ ?>